# SciDiagnose

SciDiagnose is a minimal, evidence-driven prototype for diagnosing *scientific silent failures* with real remote computation. Traditional HPC monitoring answers whether a job completed. SciDiagnose asks whether the resulting science is trustworthy.

A computational failure is an exception, missing dependency, or OOM. A scientific silent failure may exit with code zero while producing a scientifically invalid result, such as a spatially misaligned product. The agent never receives the hidden answer: it selects a general diagnostic experiment, sends it to a real compute host, observes structured evidence, and then chooses its next action.

## v0.2.2 architecture

Public task -> hypotheses -> ranked experiment plans -> novelty/coverage gate -> budget gate -> SSH Direct experiment -> scientific and compute metrics -> scoped evidence update -> reflection -> validation gate -> fault / no_fault / inconclusive.

The current real backend is SSHDirectExecutor: it uses a pre-configured SSH alias, scp, nohup, a remote PID, and result.json / failure.json. Every remote experiment records scientific metrics plus wall time, CPU time, memory, Python version, input bytes, anonymous site profile, and lifecycle events. Per-run compute_summary.json aggregates those observations.

### Evidence and compute provenance

The graph derives each experiment's authoritative `system_tested_scope` from the normalized tool call that actually ran (for example, `shift(dr=1,dc=-2)`), rather than from model prose. A specific candidate can therefore update only that candidate; one unsuccessful probe cannot reject an entire fault family. Planner rationale and predicted observations remain traceable context, not evidence claims.

Remote `cpu_seconds` and `wall_seconds` are per-experiment deltas. `process_cpu_cumulative_seconds` and `peak_rss_kib` are intentionally labelled as cumulative/peak process metrics, so summaries do not accidentally present them as per-job consumption.

## Install and configuration

Python 3.10+ and NumPy are required locally. Configure an existing SSH alias without placing credentials in this repository:

```powershell
$env:PYTHONPATH = 'src'
$env:SCIDIAG_REMOTE_HOST = 'server-114'
```

The remote host must have Python. GEO-001 also needs NumPy. SciDiagnose never installs it automatically. On the remote host, an operator may explicitly provision an isolated environment:

```bash
python3 -m venv ~/venvs/scidiag
source ~/venvs/scidiag/bin/activate
python -m pip install numpy
```

Then set `SCIDIAG_REMOTE_PYTHON=~/venvs/scidiag/bin/python` locally.

## Run

```powershell
$env:PYTHONPATH = 'src'
python scripts/probe_remote.py
python scripts/smoke_remote.py
python scripts/create_demo_case.py
python scripts/run_graph_demo.py --case b01 --agent api --host server-114
```

The smoke test runs real Python on the remote host and prints RUNNING -> COMPLETED. Graph runs upload only public arrays, execute remote NumPy experiments, and write trace.jsonl, state.json, final.json, per-experiment records, and compute_summary.json under runs/.

## Public benchmark

The public benchmark contains B01 (single spatial repair), B02 (compound repair), and B03 (no-fault). It compares direct_llm, one_shot_llm, deterministic_transform_sweep, and deterministic_full_search. The full search contains 7 transforms x 11 row shifts x 11 column shifts.

Run the deterministic baselines with:

python scripts/run_benchmark.py --cases b01 b02 b03 --methods deterministic_transform_sweep deterministic_full_search

Benchmark results are truth-blind and report budget units, remote jobs, wall/CPU time, evidence citations, and repair validation. Ground truth is evaluator-only and is never supplied to the diagnosis agent or benchmark method.

## School LLM API

SciDiagnose includes a dependency-free OpenAI-compatible client. Keep credentials out of the repository and set them in your shell:

```powershell
$env:SCIDIAG_MODEL_PROVIDER = 'openai_compatible'
$env:SCIDIAG_BASE_URL = 'https://<school-api-host>/v1'
$env:SCIDIAG_MODEL_NAME = '<school-model-name>'
$env:SCIDIAG_API_KEY = '<your-key>'
python scripts/run_graph_demo.py --case b01 --host server-114 --agent api
```

If an SSH connection is slow, set a larger per-command limit before launching:

```powershell
$env:SCIDIAG_COMMAND_TIMEOUT = '120'
```

The endpoint must implement `POST /chat/completions`. The agent receives only public task state, the neutral tool catalog, and actual experiment records; it never receives evaluator-only ground truth.

Alternatively, create a local `E:\107competition\.env` from `.env.example` and add the three model settings there. `.env` is ignored by Git and is read automatically; never send or commit it.

## Knowledge-Grounded Diagnosis — v0.3

SciDiagnose now includes a lightweight, local BM25 foundation for authoritative product manuals, algorithm documents, variable metadata, physical constraints, numerical-method documentation, and project scientific notes. Sources are manifest-declared with authority, publisher, version, retrieval date, SHA-256, domain, product, and usage note; MVP ingestion accepts only cleaned local `.txt`/`.md` sources, never LLM-generated content or raw PDFs.

The first actual corpus contains three EUMETSAT MSG/SEVIRI documents (`official`) and Satpy reader documentation (`project_documentation`). Raw documents, page-marked normalized text, source inventory, chunks, index, and retrieval smoke-test artifacts remain under `knowledge/`. The corpus records product semantics only; historical repairs are experimental evidence and are intentionally excluded.

`retrieve_scientific_knowledge(query, top_k)` is the only v0.3 knowledge action. It returns source provenance, section/page, excerpt, and retrieval score only; it never recommends a repair, cannot read evaluator-private material, and never uploads corpus content to `server-114`. The existing planner may choose it as a `Knowledge Query` diagnostic action when enabled with `scripts/run_graph_demo.py --knowledge` (C cohort); omitting that switch is the B no-RAG cohort. Both cohorts use the same planner, validation gate, tool costs, and budget accounting. Final artifacts retain experimental and knowledge evidence separately before recording the final inference.

The persisted `knowledge/index/bm25.json` is intentionally the searchable chunk store, not a precomputed term-frequency table. BM25 document frequencies and length statistics are deterministically constructed at load/search time. This keeps the first corpus small, inspectable, and free of an additional database dependency.
